export type ResponseSchema = {
  message: string;
  data?: object | [];
};
