export enum GenericType {
  NONE,
  MOTOR
}
