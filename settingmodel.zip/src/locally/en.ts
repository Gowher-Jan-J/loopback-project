export const CREATED_SUCCESS = "Setting created successfully";
export const UPDATED_SUCCESS = "Setting updated successfully";
export const DELETED_SUCCESS = "Setting deleted successfully";
export const NOTFOUND = "Data not found ";
export const INVALID_GENERIC_TYPE = "Invalid generic type";
export const SETTING_ALREADY_EXIST = "Setting already exists";
export const SETTING_NOT_FOUND = "Setting not found";
export const SUCCESS = "Success";

export const CREATED_FAILIURE = "Setting created failed"
export const UPDATED_FAILIURE = "Setting updated failed"
export const DELETE_FAILIURE = "Setting deleted failed"
export const FAILED = "FAILED"

